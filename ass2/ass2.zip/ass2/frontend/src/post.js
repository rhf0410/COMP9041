function Show() {
    document.getElementById('post_box').classList.remove('hide');
    document.getElementById('sub_post').classList.remove('hide');
}

function Hide() {
    document.getElementById('post_box').classList.add('hide');
    document.getElementById('sub_post').classList.add('hide');
}