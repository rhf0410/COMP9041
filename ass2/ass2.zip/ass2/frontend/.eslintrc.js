module.exports = {
    env: {
        browser: true
    },
    parserOptions: {
        ecmaVersion: '2017',
        sourceType: 'module'
    },
    rules: {
        'linebreak-style': ["off"]
    }
}